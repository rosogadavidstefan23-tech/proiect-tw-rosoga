const { DataTypes } = require('sequelize');
const sequelize = require('./server').sequelize;
const Activity = require('./Activity');
const Feedback = sequelize.define('Feedback', {
  emoji: {
    type: DataTypes.STRING,
    allowNull: false,
  },
  timestamp: {
    type: DataTypes.DATE,
    defaultValue: DataTypes.NOW,
  },
});
Feedback.belongsTo(Activity);
module.exports = Feedback;