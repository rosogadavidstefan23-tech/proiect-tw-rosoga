const { DataTypes } = require('sequelize');
const sequelize = require('./server').sequelize;
const Activity = sequelize.define('Activity', {
  code: {
    type: DataTypes.STRING,
    unique: true,
    allowNull: false,
  },
  description: {
    type: DataTypes.TEXT,
    allowNull: false,
  },
  date: {
    type: DataTypes.DATE,
    allowNull: false,
  },
  duration: {
    type: DataTypes.INTEGER,
    allowNull: false,
  },
});
module.exports = Activity;
