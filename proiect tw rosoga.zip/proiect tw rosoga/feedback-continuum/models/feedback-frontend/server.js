// Importă dependențele necesare
const express = require('express');
const cors = require('cors');
const dotenv = require('dotenv');
const { Sequelize } = require('sequelize');

// Încarcă variabilele de mediu din fișierul .env
dotenv.config();

// Crearea aplicației Express
const app = express();

// Permite cereri din alte domenii
app.use(cors());

// Permite procesarea cererilor JSON
app.use(express.json());

// Conectarea la baza de date MySQL folosind variabila de mediu DB_URL
const sequelize = new Sequelize(process.env.DB_URL, {
  dialect: 'mysql',
  logging: false,  // Setează la true pentru debug
});

// Verificăm conexiunea la baza de date
sequelize.authenticate()
  .then(() => {
    console.log('Conectat la MySQL!');
  })
  .catch((err) => {
    console.error('Eroare la conectare:', err);
  });

// Rutele API
app.get('/', (req, res) => {
  res.send('API este funcțional!');
});

// Importă modelele
const Activity = require('./Activity');
const Feedback = require('./Feedback');

// Ruta pentru crearea activităților
app.post('/activities', async (req, res) => {
  const { code, description, date, duration } = req.body;
  try {
    const activity = await Activity.create({ code, description, date, duration });
    res.status(201).json(activity);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
});

// Ruta pentru adăugarea feedback-ului
app.post('/feedback', async (req, res) => {
  const { emoji, activityId } = req.body;
  try {
    const feedback = await Feedback.create({ emoji, activityId });
    res.status(201).json(feedback);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
});

// Pornirea serverului pe portul 3001
app.listen(3001, () => {
  console.log('Serverul rulează pe http://localhost:3001');
});
