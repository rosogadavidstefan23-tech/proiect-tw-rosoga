import React, { useState } from 'react';
import axios from 'axios';

const ActivityForm = () => {
  const [code, setCode] = useState('');
  const [description, setDescription] = useState('');
  const [date, setDate] = useState('');
  const [duration, setDuration] = useState('');

  const handleSubmit = (e) => {
    e.preventDefault();
    axios.post('http://localhost:3001/activities', { code, description, date, duration })
      .then(response => {
        console.log(response.data);
        // Poți să adaugi și un mesaj de succes sau să resetezi formularul
      })
      .catch(error => {
        console.error('There was an error!', error);
      });
  };

  return (
    <form onSubmit={handleSubmit}>
      <input
        type="text"
        placeholder="Code"
        value={code}
        onChange={e => setCode(e.target.value)}
      />
      <input
        type="text"
        placeholder="Description"
        value={description}
        onChange={e => setDescription(e.target.value)}
      />
      <input
        type="datetime-local"
        value={date}
        onChange={e => setDate(e.target.value)}
      />
      <input
        type="number"
        placeholder="Duration"
        value={duration}
        onChange={e => setDuration(e.target.value)}
      />
      <button type="submit">Create Activity</button>
    </form>
  );
};

export default ActivityForm;