import React, { useState } from 'react';
import axios from 'axios';

const Feedback = ({ activityId }) => {
  const [emoji, setEmoji] = useState(null);

  const handleEmojiClick = (emojiType) => {
    setEmoji(emojiType);
    axios.post('http://localhost:3001/feedback', { emoji: emojiType, activityId })
      .then(response => console.log(response.data))
      .catch(error => console.error('There was an error!', error));
  };

  return (
    <div>
      <button onClick={() => handleEmojiClick('😊')}>😊</button>
      <button onClick={() => handleEmojiClick('😞')}>😞</button>
      <button onClick={() => handleEmojiClick('😲')}>😲</button>
      <button onClick={() => handleEmojiClick('😕')}>😕</button>
    </div>
  );
};

export default Feedback;